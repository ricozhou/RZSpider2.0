package javacustomspider;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;

/**
 * 爬虫JAVA代码api
 * 
 * @author rico
 * @date 2018-07-010 包括数据库连接，插入，json的处理等
 */
// 此类是直接将数据库信息写死
public class JavaCustomSpiderUtils2 {
	private Connection conn;
	// 基本信息写死且不允许下载
	private static final String url = "jdbc:mysql://127.0.0.1:3306/rzspider?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull";
	private static final String name = "com.mysql.jdbc.Driver";
	private static final String user = "root";
	private static final String password = "root";
	// 只有一个插入方法，需要三个参数，第一个是任务详情的id，表示此次数据属于哪次任务，第二个是具体的数据，第三个参数是标志，0是测试，1是正常数据，2是未经筛选的全部数据
	private String sql = "insert into spider_data (task_info_id,json_data,task_flag) values (?,?,?)";

	// 插入方法
	public boolean insertDataToMysql(String taskInfoId, String jsonData, Integer taskFlag) {
		try {
			Class.forName(name);
			this.conn = DriverManager.getConnection(url, user, password);

			PreparedStatement stmt = this.conn.prepareStatement(this.sql);
			stmt.setString(1, taskInfoId);
			stmt.setString(2, jsonData);
			stmt.setInt(3, taskFlag.intValue());
			stmt.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (this.conn != null) {
				try {
					this.conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 处理json转为对象
	public static Object jsonStringToObject(String json, Object object) {
		if ("".equals(json)) {
			return object;
		}
		object = JSONObject.parseObject(json, object.getClass());
		return object;
	}

	// 处理json(value)转为list
	public static List<String> jsonStringToList(String json) {
		List<String> objectList = new ArrayList<String>();
		// 有序遍历
		LinkedHashMap<String, String> jsonMap = JSONObject.parseObject(json,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		for (Entry<String, String> entry : jsonMap.entrySet()) {
			objectList.add(entry.getValue());
		}
		return objectList;
	}

	// 处理json转为数组
	public static String[] jsonStringToArray(String json) {
		List<String> objectList = jsonStringToList(json);
		if (objectList == null || objectList.size() < 1) {
			return null;
		}
		String[] arrayJson = new String[objectList.size()];
		objectList.toArray(arrayJson);
		return arrayJson;
	}
	// 以上是参数转换

	// 下面是爬取的数据转换
	// 对象转json
	public static String objectToJsonString(Object object) {
		String jsonString = JSONObject.toJSONString(object);
		return jsonString;
	}

	// list对象转json字符串list
	public static List<String> objectListToJsonStringList(List objectList) {
		List<String> stringList = new ArrayList<String>();
		String jsonStr = null;
		if (objectList == null || objectList.size() < 1) {
			return stringList;
		}
		for (Object object : objectList) {
			stringList.add(JSONObject.toJSONString(object));
		}

		return stringList;
	}

	public static void main(String[] args) {
		System.out.println("JavaCustomSpiderUtils");
	}
}
